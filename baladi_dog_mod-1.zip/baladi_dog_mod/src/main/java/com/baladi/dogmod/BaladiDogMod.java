package com.baladi.dogmod;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.DeferredSpawnEgg;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

@Mod(BaladiDogMod.MODID)
public class BaladiDogMod {
    public static final String MODID = "baladi_dog";

    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(BuiltInRegistries.ENTITY_TYPE, MODID);
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MODID);

    // 3x the size of a wolf (wolf = 0.6 x 0.85)
    public static final DeferredHolder<EntityType<?>, EntityType<BaladiDog>> BALADI_DOG =
            ENTITIES.register("baladi_dog", () -> EntityType.Builder
                    .of(BaladiDog::new, MobCategory.CREATURE)
                    .sized(1.8F, 2.55F)
                    .eyeHeight(2.04F)
                    .clientTrackingRange(10)
                    .build("baladi_dog"));

    public static final DeferredItem<Item> BALADI_COLLAR =
            ITEMS.registerSimpleItem("baladi_collar", new Item.Properties().stacksTo(16));

    public static final DeferredItem<DeferredSpawnEgg> BALADI_DOG_SPAWN_EGG =
            ITEMS.register("baladi_dog_spawn_egg",
                    () -> new DeferredSpawnEgg(BALADI_DOG, 0xDAAA68, 0x2C2420, new Item.Properties()));

    public BaladiDogMod(IEventBus modBus) {
        ENTITIES.register(modBus);
        ITEMS.register(modBus);
        modBus.addListener(this::registerAttributes);
        modBus.addListener(this::registerSpawnPlacements);
        modBus.addListener(this::addToCreativeTabs);
    }

    private void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(BALADI_DOG.get(), BaladiDog.createAttributes().build());
    }

    private void registerSpawnPlacements(RegisterSpawnPlacementsEvent event) {
        event.register(BALADI_DOG.get(), SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Animal::checkAnimalSpawnRules,
                RegisterSpawnPlacementsEvent.Operation.REPLACE);
    }

    private void addToCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.SPAWN_EGGS) event.accept(BALADI_DOG_SPAWN_EGG);
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) event.accept(BALADI_COLLAR);
    }
}
