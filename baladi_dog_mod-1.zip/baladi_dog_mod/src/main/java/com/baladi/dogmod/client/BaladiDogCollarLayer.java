package com.baladi.dogmod.client;

import com.baladi.dogmod.BaladiDog;
import com.baladi.dogmod.BaladiDogMod;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.resources.ResourceLocation;

public class BaladiDogCollarLayer extends RenderLayer<BaladiDog, BaladiDogModel> {
    private static final ResourceLocation COLLAR =
            ResourceLocation.fromNamespaceAndPath(BaladiDogMod.MODID, "textures/entity/baladi_dog_collar.png");

    public BaladiDogCollarLayer(RenderLayerParent<BaladiDog, BaladiDogModel> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, BaladiDog entity,
                       float limbSwing, float limbSwingAmount, float partialTick,
                       float ageInTicks, float netHeadYaw, float headPitch) {
        if (entity.isTame() && !entity.isInvisible()) {
            renderColoredCutoutModel(this.getParentModel(), COLLAR, poseStack, buffer, packedLight, entity, -1);
        }
    }
}
